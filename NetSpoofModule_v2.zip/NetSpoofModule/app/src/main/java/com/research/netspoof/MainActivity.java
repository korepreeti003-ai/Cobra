package com.research.netspoof;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    // ── UI refs ──────────────────────────────────────────────────
    private SwitchCompat swEnabled;
    private ImageView    ivAppIcon;
    private TextView     tvAppName, tvAppPkg, tvStatus;
    private EditText     etNumber, etImsi, etOperator, etSimOp,
                         etIccid, etCountry, etMccMnc, etAndroidId, etImei;
    private Button       btnSelectApp, btnSave;
    private View         cardAppEmpty, cardAppSelected;

    private SharedPreferences prefs;
    private String selectedPkg = "", selectedName = "";

    // ── App selector launcher ─────────────────────────────────────
    private final ActivityResultLauncher<Intent> appPicker =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                Intent data = result.getData();
                selectedPkg  = data.getStringExtra(AppSelectActivity.EXTRA_PKG);
                selectedName = data.getStringExtra(AppSelectActivity.EXTRA_NAME);
                updateAppCard();
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        prefs = getSharedPreferences(Prefs.FILE, Context.MODE_PRIVATE);
        bindViews();
        loadPrefs();
        setupListeners();
    }

    // ── Bind all views ────────────────────────────────────────────
    private void bindViews() {
        swEnabled      = findViewById(R.id.sw_enabled);
        ivAppIcon      = findViewById(R.id.iv_app_icon);
        tvAppName      = findViewById(R.id.tv_app_name);
        tvAppPkg       = findViewById(R.id.tv_app_pkg);
        tvStatus       = findViewById(R.id.tv_status);
        cardAppEmpty   = findViewById(R.id.card_app_empty);
        cardAppSelected= findViewById(R.id.card_app_selected);
        btnSelectApp   = findViewById(R.id.btn_select_app);

        etNumber    = findViewById(R.id.et_number);
        etImsi      = findViewById(R.id.et_imsi);
        etOperator  = findViewById(R.id.et_operator);
        etSimOp     = findViewById(R.id.et_sim_op);
        etIccid     = findViewById(R.id.et_iccid);
        etCountry   = findViewById(R.id.et_country);
        etMccMnc    = findViewById(R.id.et_mcc_mnc);
        etAndroidId = findViewById(R.id.et_android_id);
        etImei      = findViewById(R.id.et_imei);
        btnSave     = findViewById(R.id.btn_save);
    }

    // ── Load saved prefs into UI ──────────────────────────────────
    private void loadPrefs() {
        swEnabled.setChecked(prefs.getBoolean(Prefs.KEY_ENABLED, true));

        selectedPkg  = prefs.getString(Prefs.KEY_TARGET_PKG,  "");
        selectedName = prefs.getString(Prefs.KEY_TARGET_NAME, "");

        etNumber   .setText(prefs.getString(Prefs.KEY_NUMBER,     Prefs.DEF_NUMBER));
        etImsi     .setText(prefs.getString(Prefs.KEY_IMSI,       Prefs.DEF_IMSI));
        etOperator .setText(prefs.getString(Prefs.KEY_OPERATOR,   Prefs.DEF_OPERATOR));
        etSimOp    .setText(prefs.getString(Prefs.KEY_SIM_OP,     Prefs.DEF_SIM_OP));
        etIccid    .setText(prefs.getString(Prefs.KEY_ICCID,      Prefs.DEF_ICCID));
        etCountry  .setText(prefs.getString(Prefs.KEY_COUNTRY,    Prefs.DEF_COUNTRY));
        etMccMnc   .setText(prefs.getString(Prefs.KEY_MCC_MNC,    Prefs.DEF_MCC_MNC));
        etAndroidId.setText(prefs.getString(Prefs.KEY_ANDROID_ID, Prefs.DEF_ANDROID_ID));
        etImei     .setText(prefs.getString(Prefs.KEY_IMEI,       Prefs.DEF_IMEI));

        updateAppCard();
        updateStatusBadge();
    }

    // ── Button listeners ──────────────────────────────────────────
    private void setupListeners() {
        // Enable toggle
        swEnabled.setOnCheckedChangeListener((b, checked) -> updateStatusBadge());

        // Select app button (both empty state and change button)
        View.OnClickListener openPicker = v -> {
            Intent intent = new Intent(this, AppSelectActivity.class);
            intent.putExtra(AppSelectActivity.EXTRA_SEL, selectedPkg);
            appPicker.launch(intent);
        };
        btnSelectApp.setOnClickListener(openPicker);
        cardAppEmpty.setOnClickListener(openPicker);
        View changeBtn = findViewById(R.id.btn_change_app);
        if (changeBtn != null) changeBtn.setOnClickListener(openPicker);

        // Read real values from my SIM
        View btnReadReal = findViewById(R.id.btn_read_real);
        if (btnReadReal != null) btnReadReal.setOnClickListener(v -> fillRealValues());

        // Randomize all
        View btnRandom = findViewById(R.id.btn_randomize);
        if (btnRandom != null) btnRandom.setOnClickListener(v -> randomizeAll());

        // Individual randomize buttons
        setRandomBtn(R.id.btn_rand_number,    () -> etNumber.setText(randomPhone()));
        setRandomBtn(R.id.btn_rand_imsi,      () -> etImsi.setText(randomImsi()));
        setRandomBtn(R.id.btn_rand_iccid,     () -> etIccid.setText(randomIccid()));
        setRandomBtn(R.id.btn_rand_android_id,() -> etAndroidId.setText(randomHex(16)));
        setRandomBtn(R.id.btn_rand_imei,      () -> etImei.setText(randomImei()));

        // Save
        btnSave.setOnClickListener(v -> savePrefs());
    }

    private void setRandomBtn(int id, Runnable action) {
        View v = findViewById(id);
        if (v != null) v.setOnClickListener(btn -> action.run());
    }

    // ── Fill real SIM values ──────────────────────────────────────
    private void fillRealValues() {
        try {
            TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (tm == null) return;

            String num = tm.getLine1Number();
            String imsi = tm.getSubscriberId();
            String op   = tm.getNetworkOperatorName();
            String simOp= tm.getSimOperatorName();
            String cc   = tm.getSimCountryIso();
            String iccid= tm.getSimSerialNumber();
            String mccmnc = tm.getNetworkOperator();

            if (num   != null && !num.isEmpty())   etNumber.setText(num);
            if (imsi  != null && !imsi.isEmpty())  etImsi.setText(imsi);
            if (op    != null && !op.isEmpty())    etOperator.setText(op);
            if (simOp != null && !simOp.isEmpty()) etSimOp.setText(simOp);
            if (cc    != null && !cc.isEmpty())    etCountry.setText(cc);
            if (iccid != null && !iccid.isEmpty()) etIccid.setText(iccid);
            if (mccmnc!= null && !mccmnc.isEmpty())etMccMnc.setText(mccmnc);

            Toast.makeText(this, "✓ Real SIM values loaded!", Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "⚠ Phone permission needed", Toast.LENGTH_SHORT).show();
        }
    }

    // ── Randomize all fields ──────────────────────────────────────
    private void randomizeAll() {
        etNumber.setText(randomPhone());
        etImsi.setText(randomImsi());
        etIccid.setText(randomIccid());
        etAndroidId.setText(randomHex(16));
        etImei.setText(randomImei());
        Toast.makeText(this, "🎲 Random values generated!", Toast.LENGTH_SHORT).show();
    }

    // ── Save to SharedPreferences ─────────────────────────────────
    private void savePrefs() {
        if (selectedPkg.isEmpty()) {
            Toast.makeText(this, "⚠ Pehle target app select karo!", Toast.LENGTH_SHORT).show();
            return;
        }

        prefs.edit()
            .putBoolean(Prefs.KEY_ENABLED,    swEnabled.isChecked())
            .putString(Prefs.KEY_TARGET_PKG,  selectedPkg)
            .putString(Prefs.KEY_TARGET_NAME, selectedName)
            .putString(Prefs.KEY_NUMBER,      etNumber.getText().toString().trim())
            .putString(Prefs.KEY_IMSI,        etImsi.getText().toString().trim())
            .putString(Prefs.KEY_OPERATOR,    etOperator.getText().toString().trim())
            .putString(Prefs.KEY_SIM_OP,      etSimOp.getText().toString().trim())
            .putString(Prefs.KEY_ICCID,       etIccid.getText().toString().trim())
            .putString(Prefs.KEY_COUNTRY,     etCountry.getText().toString().trim())
            .putString(Prefs.KEY_MCC_MNC,     etMccMnc.getText().toString().trim())
            .putString(Prefs.KEY_ANDROID_ID,  etAndroidId.getText().toString().trim())
            .putString(Prefs.KEY_IMEI,        etImei.getText().toString().trim())
            .apply();

        btnSave.setText("✓ Saved!");
        btnSave.postDelayed(() -> btnSave.setText("💾 Save & Apply"), 1500);
        Toast.makeText(this, "✓ Config saved! Reboot app ya phone karo.", Toast.LENGTH_LONG).show();
        updateStatusBadge();
    }

    // ── UI helpers ────────────────────────────────────────────────
    private void updateAppCard() {
        if (selectedPkg.isEmpty()) {
            cardAppEmpty.setVisibility(View.VISIBLE);
            cardAppSelected.setVisibility(View.GONE);
        } else {
            cardAppEmpty.setVisibility(View.GONE);
            cardAppSelected.setVisibility(View.VISIBLE);
            tvAppName.setText(selectedName.isEmpty() ? selectedPkg : selectedName);
            tvAppPkg.setText(selectedPkg);
            try {
                Drawable icon = getPackageManager()
                        .getApplicationIcon(selectedPkg);
                ivAppIcon.setImageDrawable(icon);
            } catch (PackageManager.NameNotFoundException e) {
                ivAppIcon.setImageResource(android.R.drawable.sym_def_app_icon);
            }
        }
    }

    private void updateStatusBadge() {
        boolean on = swEnabled.isChecked() && !selectedPkg.isEmpty();
        tvStatus.setText(on ? "● ACTIVE" : "○ INACTIVE");
        tvStatus.setTextColor(getResources().getColor(
                on ? R.color.green_active : R.color.text_secondary, null));
    }

    // ── Random generators ─────────────────────────────────────────
    private final Random rng = new Random();

    private String randomPhone() {
        // India mobile: +91 7/8/9 XXXXXXXXX
        int prefix = new int[]{7, 8, 9}[rng.nextInt(3)];
        return "+91" + prefix + String.format("%09d", rng.nextInt(1_000_000_000));
    }

    private String randomImsi() {
        // MCC=404 (India) + MNC=10/45 + 10-digit MSIN
        String[] mncs = {"10", "45", "20", "07"};
        return "404" + mncs[rng.nextInt(mncs.length)]
                + String.format("%010d", (long)(rng.nextDouble() * 10_000_000_000L));
    }

    private String randomIccid() {
        return "8991" + String.format("%016d",
                (long)(rng.nextDouble() * 10_000_000_000_000_000L));
    }

    private String randomHex(int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append("0123456789abcdef".charAt(rng.nextInt(16)));
        return sb.toString();
    }

    private String randomImei() {
        // 15-digit IMEI (first 8 = TAC, last 7 = serial+checkdigit)
        StringBuilder sb = new StringBuilder("35");
        for (int i = 0; i < 13; i++) sb.append(rng.nextInt(10));
        return sb.toString();
    }
}
